alert("Hello World!");
alert("I'm Developer!");