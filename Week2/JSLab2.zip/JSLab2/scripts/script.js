//Add your work to this file. 

/* Example
This is a variable declaration. 
Also referred to as a variable definition.*/
let firstVariable; 

/* Your turn 
Define a variable named data */


/* Example
 Here we initialize firstVariable
 In other words we assign it a value for the first
 time */
 firstVariable = 100;

 /* Now we can use our variable. 
 Let's print it to the console.*/
 console.log(firstVariable);

 /*Your turn
 Initialize data to 5000*/
 firstVariable = 5000;

 /*Then print your variable to the console.*/
 console.log(firstVariable);

 const constVariable = "Can't be changed";
 console.log(constVariable);
 
/*Set my favorite food.*/
firstVariable = "Sushi";
 /*Then print my favorite food.*/
 console.log(firstVariable);

 /*Set of my favorite number.*/
 data = 88;
 /*Then print my favorite number..*/
 console.log(data);

//  constVariable = "Reassignment";

var myVar;
myVar = true;
myVar = false;
console.log(myVar);


console.log(varVariable);
console.log(abc);
let abc;
var varVariable;